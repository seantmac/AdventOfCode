# 2016 Advent of Code
Repo with solutions for the [Advent of Code][aoc], 2016 edition.

[aoc]:http://adventofcode.com/2016
